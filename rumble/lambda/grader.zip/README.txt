bootleg grader, stolen from contest website and adapted for command line

usage:

$ make
$ node grader.js ../problems/part1-all/prob-011.desc ../solutions/prob-011.sol

to update if the official grader is updated:

$ rm lambda.js index.html; make
